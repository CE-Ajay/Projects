 </section>
<section class="footeroption">
		<h2><?php echo "GEC-Gandhinagar"; ?></h2>
	</section>
</div>
</body>
</html>